var hero = document.querySelector("#hero");
var container = document.querySelector("#container");

let startTime = Date.now();
let survivalEl = document.querySelector("#survivalTime");

let killsEl = document.querySelector("#kills");

let maxEnemyHealth = 4;


let shootSound = new Audio("/assets/shotsfx.mp3");
shootSound.volume = 0.5; // optional (0 to 1)

// ================= PLAYER =================
let positionX = 600;
let speed = 8;

let moveLeft = false;
let moveRight = false;

let facing = "right";
let canShoot = true;

let gameOver = false;

let kills = 0;

// 🟢 PLAYER HEALTH (5 hits = 5 seconds)
let playerHealth = 5;
let maxHealth = 5;

// 🟢 PLAYER HEALTH BAR (like enemy but bigger & green)
let playerBar = document.createElement("div");
playerBar.style.position = "absolute";
playerBar.style.width = "120px";
playerBar.style.height = "8px";
playerBar.style.background = "green";
playerBar.style.top = "500px";   // above player
playerBar.style.left = positionX + "px";

container.appendChild(playerBar);


document.addEventListener("keydown", function (e) {
    if (gameOver && e.key.toLowerCase() === "r") {
        location.reload();
    }
});


// ================= INPUT =================
document.addEventListener("keydown", function (e) {

    if (gameOver) return;

    if (e.key === "ArrowLeft") moveLeft = true;
    if (e.key === "ArrowRight") moveRight = true;

    if (e.code === "Space" && canShoot) {
        shootBullet();
        canShoot = false;
        setTimeout(() => canShoot = true, 300);
    }
});

document.addEventListener("keyup", function (e) {
    if (e.key === "ArrowLeft") moveLeft = false;
    if (e.key === "ArrowRight") moveRight = false;
});

// ================= GAME LOOP =================
function gameLoop() {

    if (gameOver) return;

    let heroWidth = hero.offsetWidth;
    let containerWidth = container.offsetWidth;

    let elapsed = Math.floor((Date.now() - startTime) / 1000);
    survivalEl.innerText = "Survival Time: " + elapsed + "s";

    killsEl.innerText = "Kills: " + kills;

    if (moveLeft) {
        positionX -= speed;
        facing = "left";
        hero.style.transform = "scaleX(-1)";
    }

    if (moveRight) {
        positionX += speed;
        facing = "right";
        hero.style.transform = "scaleX(1)";
    }

    if (positionX < 0) positionX = 0;
    if (positionX > containerWidth - heroWidth) {
        positionX = containerWidth - heroWidth;
    }

    hero.style.left = positionX + "px";

    // 🟢 MOVE PLAYER HEALTH BAR WITH HERO
    playerBar.style.left = (positionX + 15) + "px";

    requestAnimationFrame(gameLoop);
}
gameLoop();

// ================= SHOOT =================
function shootBullet() {

    if (gameOver) return;


     // 🔊 PLAY SOUND
    shootSound.currentTime = 0; // rewind so it plays every time
    shootSound.play();


    let bullet = document.createElement("img");
    bullet.src = "/assets/bullets.png";
    bullet.style.position = "absolute";
    bullet.style.width = "40px";

    let startX = hero.offsetLeft + hero.offsetWidth / 1.8;
    let startY = hero.offsetTop + 88;

    let dir = facing;

    if (dir === "right") {
        startX = hero.offsetLeft + hero.offsetWidth - 50; // right hand/gun
        bullet.style.transform = "scaleX(1)";
    } else {
        startX = hero.offsetLeft - -10; // left side of body
        bullet.style.transform = "scaleX(-1)";
    }
    bullet.style.left = startX + "px";
    bullet.style.top = startY + "px";

    container.appendChild(bullet);

    moveBullet(bullet, dir);
}

// ================= BULLET =================
function moveBullet(bullet, dir) {

    let speedBullet = 25;

    function update() {

        if (gameOver) {
            bullet.remove();
            return;
        }

        let x = bullet.offsetLeft;
        x += (dir === "right") ? speedBullet : -speedBullet;
        bullet.style.left = x + "px";

        enemies.forEach((e, index) => {

            let b = bullet.getBoundingClientRect();
            let en = e.el.getBoundingClientRect();

            if (
                b.left < en.right &&
                b.right > en.left &&
                b.top < en.bottom &&
                b.bottom > en.top
            ) {
                e.health--;
                e.bar.style.width = (e.health / maxEnemyHealth) * 60 + "px";

                bullet.remove();

                if (e.health <= 0) {
                    kills++; // 🟢 COUNT KILL
                    e.el.remove();
                    e.bar.remove();
                    enemies.splice(index, 1);
                }
            }
        });

        if (x < 0 || x > container.offsetWidth) {
            bullet.remove();
            return;
        }

        requestAnimationFrame(update);
    }

    update();
}

// ================= ENEMIES =================
let enemies = [];

function spawnEnemy() {

    if (gameOver) return;

    let e = document.createElement("img");
    e.src = "/assets/enemchar1.png";
    e.style.position = "absolute";
    e.style.width = "100px";

    let fromLeft = Math.random() < 0.5;

    let x = fromLeft ? -100 : container.offsetWidth + 100;
    let y = 520;

    e.style.left = x + "px";
    e.style.top = y + "px";

    let bar = document.createElement("div");
    bar.style.position = "absolute";
    bar.style.width = "60px";
    bar.style.height = "6px";
    bar.style.background = "red";
    bar.style.top = (y - 10) + "px";
    bar.style.left = x + "px";

    container.appendChild(e);
    container.appendChild(bar);

    enemies.push({
        el: e,
        bar: bar,
        x: x,
        speed: 2 + Math.random() * 2,
        stuck: false,
        health: 4,
        side: fromLeft ? "left" : "right",
        lastDamageTime: 0
    });
}

setInterval(spawnEnemy, 2000);

// ================= ENEMY LOOP =================
function updateEnemies() {

    if (gameOver) return;
    let screenLeft = -150;
    let screenRight = container.offsetWidth + 150;

    enemies.forEach(e => {

        
        if (e.x < screenLeft || e.x > screenRight) {
            e.el.remove();
            e.bar.remove();
            e.removeMe = true;
            return;
        }

        let targetX = (e.side === "left")
            ? positionX - 50
            : positionX + 100;

        if (!e.stuck) {

            if (e.x > targetX) {
                e.x -= e.speed;
                e.el.style.transform = "scaleX(1)";
            } else {
                e.x += e.speed;
                e.el.style.transform = "scaleX(-1)";
            }

            if (Math.abs(e.x - targetX) < 5) {
                e.x = targetX;
                e.stuck = true;
                e.lastDamageTime = Date.now();
            }

        } else {

            e.x = targetX;

            // 🟢 DAMAGE EVERY 1 SECOND
            if (Date.now() - e.lastDamageTime > 1000) {
                e.lastDamageTime = Date.now();

                playerHealth--;

                // 🟢 prevent negative health
                if (playerHealth < 0) playerHealth = 0;

                // 🟢 update bar visually first
                playerBar.style.width = (playerHealth / maxHealth) * 120 + "px";

                // 🟢 trigger game over ONLY when truly 0
                if (playerHealth === 0) {
                    setTimeout(() => endGame(), 50);
                }
            }
        }

        e.el.style.left = e.x + "px";
        e.bar.style.left = (e.x + 20) + "px";
    });
    enemies = enemies.filter(e => !e.removeMe);
    requestAnimationFrame(updateEnemies);
    
}

updateEnemies();

// ================= GAME OVER =================
function endGame() {
    gameOver = true;

    let finalTime = Math.floor((Date.now() - startTime) / 1000);

    // 🟢 CREATE OVERLAY
    let overlay = document.createElement("div");
    overlay.id = "gameOverScreen";

    overlay.innerHTML = `
        <h1>GAME OVER 💀</h1>
        <p>Survived: ${finalTime}s</p>
        <p>Kills: ${kills || 0}</p>
        <p>Press R to Restart</p>
    `;

    container.appendChild(overlay);
}